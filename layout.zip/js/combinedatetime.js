function combineDateTime(){
    var date = document.getElementById("division").toString();
    document.getElementById("log").innerHTML = date;
}